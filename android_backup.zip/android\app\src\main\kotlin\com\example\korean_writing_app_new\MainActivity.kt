package com.example.korean_writing_app_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
